<div>
    <h2 class="text-3xl font-bold mb-6">Historial Enviado</h2>

    <!-- Campaigns History List -->
    <div class="bg-white rounded-lg shadow">
        <div class="p-6 border-b">
            <h3 class="text-xl font-semibold">Campañas Completadas</h3>
        </div>
        <div class="p-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($campaigns && $campaigns->count() > 0): ?>
                <div class="space-y-4">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border rounded p-4 hover:bg-gray-50">
                            <div class="flex justify-between items-start">
                                <div class="flex-1">
                                    <h4 class="font-semibold text-lg"><?php echo e($campaign->name); ?></h4>
                                    <p class="text-gray-600 text-sm mt-1"><?php echo e(Str::limit($campaign->content, 100)); ?></p>
                                    <div class="mt-2 flex gap-4 text-sm flex-wrap items-center">
                                        <span class="text-gray-600">
                                            Destinatarios: <strong><?php echo e(number_format($campaign->total_recipients)); ?></strong>
                                        </span>
                                        <span class="text-green-600">
                                            Enviados: <strong><?php echo e(number_format($campaign->sent_count)); ?></strong>
                                        </span>
                                        <span class="text-blue-600">
                                            Leídos: <strong><?php echo e(number_format($campaign->read_count)); ?></strong>
                                        </span>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($campaign->failed_count > 0): ?>
                                            <span class="text-red-600">
                                                Fallidos: <strong><?php echo e(number_format($campaign->failed_count)); ?></strong>
                                            </span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        <?php
                                            $statusLabels = [
                                                'completed' => 'Completado',
                                                'failed' => 'Fallido'
                                            ];
                                        ?>

                                        <span class="px-2 py-1 rounded text-xs font-semibold
                                            <?php echo e($campaign->status === 'completed' ? 'bg-green-100 text-green-800' : ''); ?>

                                            <?php echo e($campaign->status === 'failed' ? 'bg-red-100 text-red-800' : ''); ?>">
                                            <?php echo e($statusLabels[$campaign->status] ?? ucfirst($campaign->status)); ?>

                                        </span>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($campaign->completed_at): ?>
                                            <span class="text-gray-500 text-xs">
                                                Completado: <?php echo e($campaign->completed_at->format('d/m/Y H:i')); ?>

                                            </span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                                <div class="flex gap-2">
                                    <a href="<?php echo e(route('campaign.metrics', $campaign->id)); ?>"
                                       class="bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700 inline-block">
                                        Ver Métricas
                                    </a>
                                    <button wire:click="deleteCampaign(<?php echo e($campaign->id); ?>)"
                                            onclick="return confirm('¿Eliminar esta campaña del historial?')"
                                            class="bg-red-600 text-white px-4 py-2 rounded text-sm hover:bg-red-700">
                                        Eliminar
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="mt-4">
                    <?php echo e($campaigns->links()); ?>

                </div>
            <?php else: ?>
                <p class="text-center py-8 text-gray-500">No hay campañas completadas en el historial.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /Users/gio/Documents/proyectos/whatsapp/resources/views/livewire/campaign-history.blade.php ENDPATH**/ ?>