<div>
    <h2 class="text-3xl font-bold mb-6">Dashboard</h2>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Total Contactos</div>
            <div class="text-3xl font-bold text-gray-800"><?php echo e(number_format($totalContacts)); ?></div>
            <div class="text-sm text-green-600 mt-1"><?php echo e(number_format($validContacts)); ?> válidos</div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Campañas</div>
            <div class="text-3xl font-bold text-gray-800"><?php echo e(number_format($totalCampaigns)); ?></div>
            <div class="text-sm text-gray-600 mt-1"><?php echo e(number_format($totalGroups)); ?> grupos</div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Mensajes Enviados</div>
            <div class="text-3xl font-bold text-gray-800"><?php echo e(number_format($totalSent)); ?></div>
            <div class="text-sm text-green-600 mt-1"><?php echo e($deliveryRate); ?>% entregados</div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="text-sm text-gray-600 mb-1">Tasa de Lectura</div>
            <div class="text-3xl font-bold text-gray-800"><?php echo e($readRate); ?>%</div>
            <div class="text-sm text-gray-600 mt-1"><?php echo e(number_format($totalRead)); ?> leídos</div>
        </div>
    </div>

    <!-- Recent Campaigns -->
    <div class="bg-white rounded-lg shadow">
        <div class="p-6 border-b">
            <h3 class="text-xl font-semibold">Campañas Recientes</h3>
        </div>
        <div class="p-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recentCampaigns->count() > 0): ?>
                <table class="w-full">
                    <thead>
                        <tr class="border-b">
                            <th class="text-left py-2">Nombre</th>
                            <th class="text-left py-2">Estado</th>
                            <th class="text-right py-2">Enviados</th>
                            <th class="text-left py-2">Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $recentCampaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b hover:bg-gray-50">
                                <td class="py-3"><?php echo e($campaign->name); ?></td>
                                <td>
                                    <span class="px-2 py-1 rounded text-xs bg-green-100 text-green-800">
                                        <?php echo e(ucfirst($campaign->status)); ?>

                                    </span>
                                </td>
                                <td class="text-right"><?php echo e(number_format($campaign->sent_count)); ?></td>
                                <td><?php echo e($campaign->created_at->format('d/m/Y H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center py-4 text-gray-500">No hay campañas aún. ¡Crea tu primera campaña!</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /Users/gio/Documents/proyectos/whatsapp/resources/views/livewire/dashboard.blade.php ENDPATH**/ ?>